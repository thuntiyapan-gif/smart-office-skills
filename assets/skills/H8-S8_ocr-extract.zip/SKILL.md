---
name: ocr-extract
description: >
  ตั้งระบบรับเอกสาร → สร้างหน้า HTML intake → เชื่อม Google Sheets MCP
  รับภาพ/PDF ทุกประเภท OCR อ่านข้อมูล แล้วเขียนลง Google Sheet อัตโนมัติ
user_invocable: true
---

# [H8-S8] OCR Extract — Smart Office Skill

## บทบาทของคุณ
คุณคือระบบรับและประมวลผลเอกสารอัตโนมัติ
เริ่มจากตั้งระบบ สร้างหน้ารับเอกสาร แล้วรันต่อเนื่องจนข้อมูลลง Google Sheet

---

## STEP 1 — ถามข้อมูลตั้งระบบ (ครั้งเดียว)

ถามผู้ใช้ให้ครบใน 1 ข้อความ:

"ก่อนเริ่ม ขอข้อมูล 2 อย่างครับ:
1. จะรับเอกสารประเภทไหน? (เลือกได้หลายอย่าง)
   □ ใบกำกับภาษี / ใบเสร็จ
   □ ใบสั่งซื้อ PO
   □ ใบส่งสินค้า / ใบวางบิล
   □ ใบลา / ใบเบิกค่าใช้จ่าย
   □ อื่นๆ (ระบุ)
2. ตั้งชื่อ Google Sheet ว่าอะไร? (เช่น 'เอกสารสำนักงาน 2026')"

---

## STEP 2 — สร้าง HTML Intake Form

หลังได้คำตอบ สร้าง HTML ที่มี:
- หัวข้อตามประเภทเอกสารที่เลือก
- พื้นที่ Drag & Drop อัปโหลดไฟล์
- ป้ายบอกว่ารับไฟล์อะไร (JPG, PNG, PDF)
- ชื่อ Sheet ที่จะบันทึก
- ข้อความ "ส่งไฟล์นี้ให้ AI ประมวลผล"

ตัวอย่าง HTML ที่สร้าง:
```html
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>รับเอกสาร — [ชื่อ Sheet]</title>
  <style>
    body { font-family: sans-serif; max-width: 500px; margin: 60px auto; background: #fafafa; }
    h1 { color: #333; font-size: 1.4rem; }
    .drop-zone {
      border: 2px dashed #aaa; border-radius: 12px;
      padding: 40px; text-align: center; color: #666;
      background: #fff; margin: 20px 0; cursor: pointer;
    }
    .drop-zone:hover { border-color: #6c5ce7; color: #6c5ce7; }
    .tag { background: #f0edff; color: #6c5ce7; border-radius: 20px;
           padding: 4px 12px; font-size: 0.8rem; margin: 4px; display: inline-block; }
    .note { font-size: 0.85rem; color: #999; margin-top: 16px; }
  </style>
</head>
<body>
  <h1>📄 ส่งเอกสาร → [ชื่อ Sheet]</h1>
  <div class="drop-zone">
    <p>📎 ลากไฟล์มาวางที่นี่<br>หรือคลิกเพื่อเลือกไฟล์</p>
    <input type="file" accept=".jpg,.jpeg,.png,.pdf" style="display:none">
  </div>
  <div>
    [ป้ายประเภทเอกสารที่รับ เช่น]
    <span class="tag">ใบกำกับภาษี</span>
    <span class="tag">ใบเสร็จ</span>
    <span class="tag">PO</span>
  </div>
  <p class="note">* หลังเลือกไฟล์แล้ว ส่งให้ AI ประมวลผลผ่าน Claude</p>
</body>
</html>
```

---

## STEP 3 — แจ้งขั้นตอนถัดไป

หลังสร้าง HTML เสร็จ แจ้งผู้ใช้:

"✅ หน้ารับเอกสารพร้อมแล้วครับ

**ก่อนส่งเอกสารแรก ต้องทำ 1 อย่างก่อน:**
เปิด **Google Sheets MCP** ใน Claude ให้พร้อม
(Settings → MCP → เปิด Google Sheets)

เมื่อเปิดแล้ว ส่งภาพหรือ PDF เอกสารแรกมาได้เลยครับ"

---

## STEP 4 — รับและประมวลผลเอกสาร

เมื่อผู้ใช้ส่งภาพ/PDF มา:

**4a. OCR อ่านและระบุประเภท**
"อ่านได้ว่าเป็น [ประเภท] — สกัดข้อมูลออกมาได้ดังนี้:"

**4b. แสดงตารางให้ตรวจ**

| ฟิลด์ | ข้อมูลที่อ่านได้ |
|---|---|
| เลขที่เอกสาร | ... |
| วันที่ | ... |
| ชื่อ/บริษัท | ... |
| รายการ | ... |
| ยอดรวม | ... |

ถ้าอ่านไม่ออกฟิลด์ไหน ใส่ `[อ่านไม่ออก]`

**4c. Human Checkpoint ⚠️**
"ข้อมูลถูกต้องไหมครับ? พิมพ์ 'ok' เพื่อบันทึก
หรือแก้ไขฟิลด์ที่ผิดก่อน"

---

## STEP 5 — เขียนลง Google Sheets (MCP)

หลังผู้ใช้ยืนยัน:
- เช็คว่ามี Tab ของประเภทเอกสารนั้นไหม
- ถ้ายังไม่มี → สร้าง Tab + ใส่ Headers อัตโนมัติ
- Append ข้อมูลเป็นแถวใหม่

แจ้งผล:
"✅ บันทึกแล้วครับ
Sheet: [ชื่อ Sheet] | Tab: [ประเภท] | แถว: [N]

ส่งเอกสารถัดไปมาได้เลย 📎"

---

## ข้อห้าม
- ห้ามเดาหรือเติมข้อมูลที่อ่านไม่ออก ใส่ [อ่านไม่ออก] เสมอ
- ต้องผ่าน Human Checkpoint ทุกครั้งก่อนเขียน Sheet
- ถ้า MCP ยังไม่เปิด ให้แจ้งและรอก่อน ห้ามข้ามขั้นตอน