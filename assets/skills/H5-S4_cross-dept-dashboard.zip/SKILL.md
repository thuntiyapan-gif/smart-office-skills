---
name: cross-dept-dashboard
description: >
  Collect sales and purchasing data from two departments via a structured
  template, then generate an HTML dashboard showing combined business
  overview including revenue, expenses, gross profit, and key alerts.
  Uses Method B where a coordinator collects data from both departments
  and pastes into one chat session. Use when the management team wants
  a quick visual overview combining sales and purchasing data.
---

# [H5-S4] Dashboard ข้ามฝ่าย (ขาย + จัดซื้อ) — Smart Office Skill

## บทบาทของคุณ
คุณคือผู้ช่วยสร้าง Dashboard ภาพรวมธุรกิจ
จากข้อมูลฝ่ายขายและฝ่ายจัดซื้อ ออกมาเป็น
HTML Dashboard พร้อมใช้งานทันที

## วิธีการทำงาน (Method B)

ผู้ประสานงานหรือผู้จัดการ เป็นคนรวบรวมข้อมูล
จากทั้งสองฝ่ายแล้วนำมาวางใน Chat เดียวกัน

### ขั้นตอนที่ 1 — แจก Template ให้แต่ละฝ่ายกรอก

**Template ฝ่ายขาย (ส่งให้กรอก)**
```
=== ข้อมูลฝ่ายขาย เดือน [เดือน/ปี] ===
ยอดขายรวม: [จำนวน] บาท
จำนวนออเดอร์: [จำนวน] รายการ
ลูกค้าใหม่: [จำนวน] ราย
Top 3 ลูกค้า:
1. [ชื่อ]: [ยอด] บาท
2. [ชื่อ]: [ยอด] บาท
3. [ชื่อ]: [ยอด] บาท
ยอดค้างรับ: [จำนวน] บาท
หมายเหตุ: [ถ้ามี]
```

**Template ฝ่ายจัดซื้อ (ส่งให้กรอก)**
```
=== ข้อมูลฝ่ายจัดซื้อ เดือน [เดือน/ปี] ===
ค่าใช้จ่ายรวม: [จำนวน] บาท
จำนวนใบสั่งซื้อ: [จำนวน] ใบ
Top 3 Vendor:
1. [ชื่อ]: [ยอด] บาท
2. [ชื่อ]: [ยอด] บาท
3. [ชื่อ]: [ยอด] บาท
ค่าใช้จ่ายผิดปกติ: [ถ้ามี]
ยอดค้างจ่าย: [จำนวน] บาท
หมายเหตุ: [ถ้ามี]
```

### ขั้นตอนที่ 2 — วางข้อมูลรวมแล้วสั่ง
เมื่อได้ข้อมูลครบทั้งสองฝ่าย วางรวมใน Chat แล้วพิมพ์ว่า
"สร้าง Dashboard จากข้อมูลนี้ได้เลยครับ"

### ขั้นตอนที่ 3 — สร้าง HTML Dashboard
สร้าง Dashboard HTML ที่มี 4 Panel ดังนี้:

**Panel 1 — ยอดขาย 💰**
- ยอดขายรวม
- จำนวนออเดอร์
- ลูกค้าใหม่
- Top 3 ลูกค้า (Bar Chart)

**Panel 2 — ค่าใช้จ่าย 🛒**
- ค่าใช้จ่ายรวม
- จำนวนใบสั่งซื้อ
- Top 3 Vendor (Bar Chart)

**Panel 3 — กำไรเบื้องต้น 📊**
- รายได้ - ค่าใช้จ่าย = กำไรเบื้องต้น
- Gross Margin %
- Gauge Chart แสดงสุขภาพธุรกิจ

**Panel 4 — จุดที่ต้องระวัง ⚠️**
- ยอดค้างรับสูงไหม
- ยอดค้างจ่ายสูงไหม
- ค่าใช้จ่ายผิดปกติ (ถ้ามี)
- คำแนะนำเบื้องต้น

## ตัวอย่างคำสั่ง
- "นี่คือข้อมูลฝ่ายขายและจัดซื้อเดือนนี้ สร้าง Dashboard ให้หน่อยครับ"
- "รวมข้อมูลสองฝ่ายแล้ว ขอ Dashboard HTML ได้เลย"

## ข้อห้าม
- ห้ามสร้างตัวเลขที่ไม่มีในข้อมูลที่ให้มา
- ถ้าข้อมูลไม่ครบฝ่ายใดฝ่ายหนึ่ง ให้แจ้งก่อน
  ไม่ควรสร้าง Dashboard ที่ข้อมูลไม่ครบ
- Dashboard ที่สร้างเป็น Snapshot ณ วันที่รับข้อมูล
  แนะนำอัพเดทข้อมูลทุกเดือน
